<div align="center">
  <img src="https://i.ibb.co/r3wmpwr/LOGO.jpg" width="300" height="300">
  <h1>👸💎 QUEEN AMDI BOT 💎👸</h1>
</div>
<p align="center">
    Makes it easy and fun to use WhatsApp. It is also the first Sinhala user bot for WhatsApp.
    <br>
        <a href="https://chat.whatsapp.com/FufFv6v1M288le5TopCNMQ">Whatsapp Group</a> |
        <a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">Youtube Channel</a>
    <br>
</p>

----
<div align="center">
	<h1>Visit our official website to install the Whatsapp Bot (With button update) :</h1>
	<a href="https://www.amdaniwasa.com">
<img src="https://images.squarespace-cdn.com/content/v1/580515742e69cfedd1fbef58/1525386767826-Z6T2PAXQD6PZJFNGY14U/ke17ZwdGBToddI8pDm48kGzbt7cz3CKX9Rsta-RdWeJZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZUJFbgE-7XRK3dMEBRBhUpwXPcCdCfJzTjuw7eD5qoJaUvNnrlJ7-JqE3xnP9OqaaXMr3zNNd3H5Lklmgn1mB80/getbutton.png" width="400"></br></a>
</div>

----
<div align="center">
	<h2>Queen Amdi v3 whatsapp bot (Old bot without buttons) :</h1>
	
### QR CODE
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@BlackAmda/Queen-Amdi-QR-Code)

### Deploy OLD v3 Queen Amdi Bot
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://github.com/BlackAmda/QueenAmdi-v3)
</div>

----

<p align="center">
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/docker/pulls/blackamda/queenamdi?style=flat-square&label=Docker+Pulls">
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/docker/image-size/blackamda/queenamdi?style=flat-square&logo=github&label=Image Size">
    
  </a>
</p>

<p align="center">

  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FBlackAmda%2FQueenAmdi&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/fork">
    <img src="https://img.shields.io/github/forks/BlackAmda/QueenAmdi?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/stargazers">
    <img src="https://img.shields.io/github/stars/BlackAmda/QueenAmdi?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/repo-size/BlackAmda/QueenAmdi?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/license/BlackAmda/QueenAmdi?color=purple&label=License&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/languages/top/BlackAmda/QueenAmdi?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/static/v1?label=Author&message=Black%20Amda&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://wa.me/94757405652">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Queen%20Amdi%20Bot-purple&style=plastic">

  </a>
</p>
 
```
Queen Amdi bot is an UserBot for WhatsApp That allowing you to get done so many tasks.
The user is responsible for all possible consequences of misuse.
This is not a Open-Source project. This is just a project that allow you to get deploy a bot.
Additionally, it enables plug-in support for users.
Install their own plugins to the original software and use as they please.
Usage is entirely the responsibility of the user. The operating system is not responsible.
HAVE A FUN!
```

## Visit our official website to install the Whatsapp Bot :
QR Code generator and full instructions available there.
<div>
	<a href="https://www.amdaniwasa.com">
<img src="https://i.ibb.co/dr27VyW/59060c190cbeef0acff9a657.png" width="200"></br></a>
</div>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BlackAmda/QueenAmdi)

## Queen Amdi Team

<table>
										<tbody>
											<tr>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://i.ibb.co/r7vZVqw/1-Amda.jpg" width="200" height="200" alt="Black Amda"></a></td>
												<td><a href="https://www.instagram.com/sinhalaya_official_/"><img src="https://i.ibb.co/tsFBnbx/2-Sasmitha.jpg" width="200" height="200" alt="sᴀsᴍɪᴛʜᴀ"></a></td>
												<td><a href="https://www.instagram.com/saji_x.x_4/"><img src="https://i.ibb.co/6FZsnvQ/3-Sajiya.jpg" width="200" height="200" alt="ʟɪʟ ʟᴜᴢɪ"></a></td>
											</tr>
										</tbody>
									</table>
                  <table>
										<tbody>
											<tr>
												<td><a href="https://dinaaofficial.github.io/dina-official/"><img src="https://i.ibb.co/rvYYcVD/4-Dina.jpg" width="200" height="200" alt="ᴍʀ.ᴅɪɴᴀ"></a></td>
												<td><a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ"><img src="https://i.ibb.co/HzfN8pD/5-Joka.jpg" width="200" height="200" alt="ᴊᴏᴋᴀ ᴛᴀᴍᴀ"></a></td>
                        <td><a href="httsp://github.com/BlackAmda/"><img src="https://i.ibb.co/bj4LqJh/6-Kapaya.jpg" width="200" height="200" alt="ᴋᴀᴘᴀʏᴀ"></a></td>
											</tr>
									</table>
                  <table>
										<tbody>
											<tr>
												<td><a href="https://www.thinknfree.com/"><img src="https://i.ibb.co/2kHWJBD/7-Zeus.jpg" width="200" height="200" alt="ᴢᴇᴜs"></a></td>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://i.ibb.co/x3MjnWn/8-Pancha.jpg" width="200" height="200" alt="ZEYREX"></a></td>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://i.ibb.co/ySvhR4J/9-Saiko.jpg" width="200" height="200" alt="sɪɢᴇᴅᴇʀɪᴇɴ"></a></td>
											</tr>
										</tbody>
									</table>

### License
This project is protected by the `GNU General Public License v3.0.`
Do not edit copyright messages!

### Disclaimer
`WhatsApp` name, its variations and logo are registered trademarks on Facebook. We have nothing to do with the registered trademark.
