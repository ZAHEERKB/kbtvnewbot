/*
░██████╗░██╗░░░██╗███████╗███████╗███╗░░██╗
██╔═══██╗██║░░░██║██╔════╝██╔════╝████╗░██║
██║██╗██║██║░░░██║█████╗░░█████╗░░██╔██╗██║
╚██████╔╝██║░░░██║██╔══╝░░██╔══╝░░██║╚████║
░╚═██╔═╝░╚██████╔╝███████╗███████╗██║░╚███║
░░░╚═╝░░░░╚═════╝░╚══════╝╚══════╝╚═╝░░╚══╝
░█████╗░███╗░░░███╗██████╗░██╗
██╔══██╗████╗░████║██╔══██╗██║
███████║██╔████╔██║██║░░██║██║
██╔══██║██║╚██╔╝██║██║░░██║██║ █▀█ █▀▀█ █▀█ ▄█─ 
██║░░██║██║░╚═╝░██║██████╔╝██║ ─▄▀ █▄▀█ ─▄▀ ─█─ 
╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═════╝░╚═╝ █▄▄ █▄▄█ █▄▄ ▄█▄
Copyright (C) 2021 Black Amda.
Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.
*/

const QueenAmdi = require('queenamdi-public');
const Amdi = QueenAmdi.events
const Build = QueenAmdi.build
const _amdi = QueenAmdi.misc
const { MessageType } = require('@blackamda/queenamdi-web-api');

const Language = require('../language');
const Lang = Language.getString('movie');
let Work_Mode = Build.WORKTYPE == 'public' ? false : true

//Movie-scraper

Amdi.operate({ pattern: 'movie ?(.*)', fromMe: Work_Mode, desc: Lang.MOVIE_DESC ,  deleteCommand: false}, (async (amdiMSG, input) => {
	await QueenAmdi.amdi_setup()
	const movie = input[1]
	if (movie === '') return await amdiMSG.client.sendMessage(amdiMSG.jid, Lang.MOVIE_NAME, MessageType.text, { quoted: amdiMSG.data });
	await _amdi.movie( amdiMSG, movie )
}));